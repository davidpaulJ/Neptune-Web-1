import { useState } from 'react';
import { CgArrowsExchangeAltV } from 'react-icons/cg';

export default function CryptoConverter() {
  const conversionFactor = 3;
  const [nep, setNep] = useState<number | undefined>();
  const [busd, setBusd] = useState<number | undefined>();

  function handleNEPChange(e: React.FormEvent<HTMLInputElement>) {
    const value = Number(e.currentTarget.value);
    setNep(value);
    setBusd(Number((value * conversionFactor).toFixed(2)));
  }

  function handleBUSDChange(e: React.FormEvent<HTMLInputElement>) {
    const value = Number(e.currentTarget.value);
    setBusd(value);
    setNep(Number((value / conversionFactor).toFixed(2)));
  }

  return (
    <div className="flex flex-col items-center my-2">
      <p className="text-xl">Crypto Converter</p>
      <div className="form-control">
        <span className="label font-bold">NEP</span>
        <input
          type="number"
          className="font-bold"
          value={nep}
          onChange={handleNEPChange}
        />
      </div>
      <CgArrowsExchangeAltV size="30" />
      <div className="form-control">
        <span className="label font-bold">BUSD</span>
        <input type="number" value={busd} onChange={handleBUSDChange} />
      </div>
    </div>
  );
}
