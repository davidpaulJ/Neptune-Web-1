import React, { useEffect, useState } from 'react';
import Web3 from 'web3';
import { useWeb3React } from '@web3-react/core';
import { injectedConnector } from '../utils/wallet/connectors';

interface WalletDetailsProps {
  onDisconnect: () => void;
}

export default function WalletDetails({ onDisconnect }: WalletDetailsProps) {
  const { account, activate, library, deactivate, chainId } = useWeb3React();
  const [balance, setBalance] = useState<number | undefined>();

  useEffect(() => {
    if (account) {
      getWalletBalance();
    } else {
      setBalance(undefined);
    }
  }, [account]);

  async function getWalletBalance() {
    if (account && library) {
      (library as Web3).eth.getBalance(account).then((i) => {
        if (Number(i) >= 0) {
          setBalance(Number(i));
        }
      });
    }
  }

  async function connectWallet(): Promise<void> {
    try {
      await activate(injectedConnector);
    } catch (ex) {
      alert('An error occured while connecting wallet.');
    }
  }

  async function disconnectWallet(): Promise<void> {
    try {
      await deactivate();
      onDisconnect();
    } catch (ex) {
      alert('An error occured while disconnecting wallet.');
    }
  }

  return (
    <div className="text-center">
      <span className="text-lg">Wallet Details</span>
      <div className="w-[600px] my-4">
        {account ? (
          <>
            <table className="text-left my-4 w-full">
              <tbody>
                <tr>
                  <td className="font-semibold">Account</td>
                  <td>{account}</td>
                </tr>
                <tr>
                  <td className="font-semibold">Chain ID</td>
                  <td>{chainId}</td>
                </tr>
                <tr>
                  <td className="font-semibold">Balance</td>
                  <td>{balance !== undefined ? balance?.toFixed(2) : ''}</td>
                </tr>
              </tbody>
            </table>
            <button
              onClick={disconnectWallet}
              className="w-48 danger float-right"
            >
              Disconnect
            </button>
          </>
        ) : (
          <div>
            <p>
              Wallet is not connected. Please click the "Connect" button below.
            </p>
            <button className="w-48 mt-12" onClick={connectWallet}>
              Connect
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
