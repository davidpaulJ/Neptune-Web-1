import { useState } from 'react';
import type { NextPage } from 'next';
import Modal from 'react-modal';
import CryptoConverter from '../components/CryptoConverter';
import WalletDetails from '../components/WalletDetails';

const Home: NextPage = () => {
  const [isDetailsOpen, setIsDetailsOpen] = useState<boolean>(false);

  const modalStyle = {
    content: {
      top: '50%',
      left: '50%',
      right: 'auto',
      bottom: 'auto',
      marginRight: '-50%',
      transform: 'translate(-50%, -50%)',
      borderRadius: '12px',
      paddingTop: '25px',
    },
    overlay: {
      background: '#1f1f1f82',
    },
  };

  return (
    <div className="flex flex-col items-center justify-center h-screen">
      <div className="text-white flex items-center text-2xl font-semi">
        <img src="/neptune.png" className="w-24 mr-3" />
        NEPTUNE MUTUAL
      </div>
      <div className="text-center px-16 py-10 m-6 w-[500px] bg-stone-100 rounded-xl drop-shadow">
        <CryptoConverter />
        <a href="#" onClick={() => setIsDetailsOpen(true)}>
          {' '}
          Check Wallet Details
        </a>
      </div>
      <Modal ariaHideApp={false} isOpen={isDetailsOpen} style={modalStyle}>
        <a
          onClick={(e) => setIsDetailsOpen(false)}
          className="text-sm font-bold float-right mb-2 text-black"
        >
          X
        </a>
        <WalletDetails onDisconnect={() => setIsDetailsOpen(false)} />
      </Modal>
    </div>
  );
};

export default Home;
